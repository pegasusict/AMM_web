"""Entry-point shim for the AMM web app."""

from AMM_web.AMM_web import app

__all__ = ["app"]
