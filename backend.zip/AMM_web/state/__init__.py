"""Reactive state for AMM-related features."""
