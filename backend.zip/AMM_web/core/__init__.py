"""Core utilities for the AMM web app."""
