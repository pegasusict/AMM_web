"""Pydantic models for AMM domain entities."""
